from flask import Flask
from flask_mongoalchemy import MongoAlchemy

app =  Flask(__name__)

app.config['MONGOALCHEMY_DATABASE'] = 'db_images'
app.config['MONGOALCHEMY_CONNECTION_STRING'] = 'mongodb://localhost:27017/'
db = MongoAlchemy(app)

class new_user(db.Document):
    uname = db.StringField()
    password = db.StringField()
